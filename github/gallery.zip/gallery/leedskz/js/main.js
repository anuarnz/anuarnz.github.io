$(function () {
    //  main promo Slider //
    // $(document).ready(function () {
    //     $('.promo__slider').slick({
    //         dots: false,
    //         infinite: true,
    //         speed: 500,
    //         fade: true,
    //         slidesToShow: 1,
    //         autoplay: true,
    //         autoplaySpeed: 4000,
    //         arrows: false,
    //         cssEase: 'linear'
    //     });
    // });

    // burger-mobile
    $('.header-mobile__burger').click(function (event) {
        $('.header-mobile__burger, .header-mobile__bottom').toggleClass('active');
        $('body').toggleClass('lock');
    });

    // main catalog slider //
    $('.catalog-slider__row').slick({
        nextArrow: '<button type="button" class="slick-btn slick-next"></button>',
        prevArrow: '<button type="button" class="slick-btn slick-prev"></button>',
        infinite: true,
        dots: false,

        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    easing: 'ease',
                }
            },
            {
                dots: false,
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    easing: 'ease',
                }
            }
        ]
    });

    // accordion footer //
    ! function (i) {
        var o, n;
        i(".title__block").on("click", function () {
            o = i(this).parents(".accordion__item"), n = o.find(".info"),
                o.hasClass("active__block") ? (o.removeClass("active__block"),
                    n.slideUp()) : (o.addClass("active__block"), n.stop(!0, !0).slideDown(),
                        o.siblings(".active__block").removeClass("active__block").children(
                            ".info").stop(!0, !0).slideUp())
        })
    }(jQuery);

    // Filter для категории страница SHOP.html //
    let filter = $("[data-filter]");

    filter.on("click", function (event) {
        event.preventDefault();

        let cat = $(this).data('filter');

        if (cat == 'all') {
            $("[data-cat]").removeClass("hide");
        } else {
            $("[data-cat]").each(function () {
                let workCat = $(this).data('cat');

                if (workCat != cat) {
                    $(this).addClass('hide');
                } else {
                    $(this).removeClass('hide');
                }
            });
        }
    });

    // Page-product product.html //
    $('.slider-for').slick({
        nextArrow: '<button type="button" class="slick-btn slick-next"></button>',
        prevArrow: '<button type="button" class="slick-btn slick-prev"></button>',
        slidesToShow: 1,
        slidesToScroll: 1,
        easing: 'ease',
        arrows: true,
        fade: true,
        asNavFor: '.slider-nav'
    });
    $('.slider-nav').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        asNavFor: '.slider-for',
        dots: false,
        arrows: false,
        focusOnSelect: true,
        responsive: [
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 3,
                    easing: 'ease',
                }
            },
            {
                dots: false,
                breakpoint: 480,
                settings: {
                    slidesToShow: 2,
                    easing: 'ease',
                }
            }
        ]
    });

    // accordion detail product //
    ! function (i) {
        var o, n;
        i(".product__block").on("click", function () {
            o = i(this).parents(".product__accordion-item"), n = o.find(".product__information"),
                o.hasClass("product__active") ? (o.removeClass("product__active"),
                    n.slideUp()) : (o.addClass("product__active"), n.stop(!0, !0).slideDown(),
                        o.siblings(".product__active").removeClass("product__active").children(
                            ".product__information").stop(!0, !0).slideUp())
        })
    }(jQuery);

    //E-mail Ajax Send
    $("form").submit(function () { //Change
        var th = $(this);
        $.ajax({
            type: "POST",
            url: "mail.php", //Change
            data: th.serialize()
        }).done(function () {
            alert("Спасибо!");
            setTimeout(function () {
                // Done Functions
                th.trigger("reset");
            }, 1000);
        });
        return false;
    });

    // при клике на товар меняется картинка (страница "product-detail-shop.html") //
    // document.body.onclick = function (event) {
    //     event = event || window.event;
    //     if (event.target.classList.contains('product-min')) {
    //         // remove .active class in .goods-img-min divs
    //         var allDivs = document.querySelectorAll('product-slider__nav div');
    //         for (var i = 0; i < allDivs.length; i++) {
    //             allDivs[i].classList.remove('active-img');
    //         }

    //         document.getElementById('product-max').src = event.target.src;
    //         event.target.parentElement.classList.add('active-img');
    //     }
    // }

});