$(function () {

  $('.header__slider').slick({
    nextArrow: '<button type="button" class="slick-btn slick-next"></button>',
    prevArrow: '<button type="button" class="slick-btn slick-prev"></button>',
    arrows: true,
    dots: true,
    infinite: true,
    speed: 800,
    autoplay: true,
    autospeed: 5000,
    fade: true,
    cssEase: 'ease',
    responsive: [
      {
        breakpoint: 769,
        settings: {
          arrows: false,
          autoplay: false,
        }
      },
    ]
  });

  $('.fancybox').fancybox({
    padding: 0,
    openEffect: 'elastic',
    closeBtn: false
  });

  // Filter для последних проектов дизайна интерьера//
  let filter = $("[data-filter]");

  filter.on("click", function (event) {
    event.preventDefault();

    let cat = $(this).data('filter');

    if (cat == 'all') {
      $("[data-cat]").removeClass("hide");
    } else {
      $("[data-cat]").each(function () {
        let workCat = $(this).data('cat');

        if (workCat != cat) {
          $(this).addClass('hide');
        } else {
          $(this).removeClass('hide');
        }
      });
    }
  });

  $('#parallax').stellar();

  $(window).on("load", function () {
    $("a[rel='m_PageScroll2id']").mPageScroll2id({
      scrollSpeed: 900,
      scrollingEasing: "easeInOutQuint",
      offset: 80
    });
  });

  $("#navToggle").click(function () {
    $(this).toggleClass("active");
    $(".overlay").toggleClass("open");
    // this line ▼ prevents content scroll-behind
    $("body").toggleClass("locked");
  });

});