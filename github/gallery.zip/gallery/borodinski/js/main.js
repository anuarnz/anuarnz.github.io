$(function(){
    $('.header-row__burger').click(function(event) {
        $('.header-row__burger,.menu').toggleClass('active');
        $('body').toggleClass('lock');
    });

    $('.pg-slider__inner').slick({
        nextArrow: '<button type="button" class="slick-btn slick-next">Вперед</button>',
        prevArrow: '<button type="button" class="slick-btn slick-prev">Назад</button>',
        infinite: false,
    });

});